{\rtf1\ansi\ansicpg1252\cocoartf1504\cocoasubrtf760
{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\fswiss\fcharset0 ArialMT;}
{\colortbl;\red255\green255\blue255;\red26\green26\blue26;\red255\green255\blue255;}
{\*\expandedcolortbl;;\cssrgb\c13333\c13333\c13333;\cssrgb\c100000\c100000\c100000;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 Nathan Conroy\
CSC 214\
TA: 
\f1\fs25\fsmilli12800 \cf2 \cb3 \expnd0\expndtw0\kerning0
Mariana Flores Kim\
Assignment 2\
\
This assignment served as an introduction to using layouts, as well as buttons and action listeners. For my main layout, i used a relative layout, which contained another relative layout inside of it as well as a linear layout. The linear layout was used for my "Happy Toast" and "Sad Toast" buttons, which display toasts when they are clicked. The inner relative layout contains a textview with the number "100", and a "Decrement" button. When the button is clicked, the number in the textview decreases by one. For extra functionality, I included a "Reset Counter" button in the bottom left corner of the display that resets the textview back to "100".}